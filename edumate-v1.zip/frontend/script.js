///// ====== Auto-detect API base ======
function detectApiBase() {
  const origin = window.location.origin || "";
  if (origin.includes("localhost") || origin.includes("127.0.0.1")) {
    return "http://127.0.0.1:8080";
  }
  return origin;
}
const API_BASE = detectApiBase();

///// ====== API helpers ======
async function apiPost(path, body = {}) {
  if (!path.startsWith("/")) path = "/" + path;
  const url = `${API_BASE}${path}`;
  return fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function apiGet(path) {
  if (!path.startsWith("/")) path = "/" + path;
  const url = `${API_BASE}${path}`;
  return fetch(url, { method: "GET" });
}

///// ====== Utils ======
function norm(s) {
  return String(s || "").trim().replace(/\s+/g, " ").toLowerCase();
}
function qText(q) {
  return q.q || q.question || q.text || "";
}

///// ====== SPLASH + attach quiz start listener after DOM ready ======
window.addEventListener("DOMContentLoaded", () => {
  const overlay = document.getElementById("loadingOverlay");
  overlay && overlay.classList.add("hidden");
  if (document.body.classList.contains("splash")) {
    setTimeout(() => {
      window.location.href = "login.html";
    }, 1500);
  }

  // start button (quiz)
  const quizBtn = document.getElementById("startQuiz");
  if (quizBtn) {
    quizBtn.addEventListener("click", async () => {
      const username = localStorage.getItem("username");
      if (!username) {
        alert("Silakan login dulu.");
        return;
      }
      try {
        const category = document.getElementById("quizCategory")?.value || "umum";
        const total = parseInt(document.getElementById("quizTotal")?.value) || 15;

        // Panggil endpoint create quiz (POST /api/quiz)
        const res = await apiPost("/api/quiz", { username, category, total });
        const data = await res.json().catch(() => ({}));

        if (!res.ok || !data.questions || !Array.isArray(data.questions)) {
          throw new Error(data.error || "Soal quiz tidak tersedia.");
        }

        startQuiz(data.questions, data.quiz_id);
      } catch (err) {
        console.error("Quiz error:", err);
        alert("Gagal memulai quiz.");
      }
    });
  }
});

///// ====== LOGIN ======
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("loginMessage");
    msgEl && (msgEl.innerText = "");

    const username = (document.getElementById("username") || {}).value || "";
    const password = (document.getElementById("password") || {}).value || "";
    if (!username || !password) {
      msgEl && (msgEl.innerText = "Username dan password wajib diisi.");
      return;
    }

    try {
      // ✅ pakai /api/auth/login
      const res = await apiPost("/api/auth/login", { username, password });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data.success) {
        const msg = data.msg || data.error || data.message || "Login gagal.";
        msgEl && (msgEl.innerText = msg);
        return;
      }

      localStorage.setItem("username", username);
      msgEl && (msgEl.innerText = "Login berhasil. Mengalihkan...");
      setTimeout(() => (window.location.href = "home.html"), 800);
    } catch (err) {
      console.error("Login error:", err);
      msgEl && (msgEl.innerText = "Gagal terhubung ke server.");
    }
  });
}

///// ====== REGISTER ======
const regForm = document.getElementById("registerForm");
if (regForm) {
  regForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("registerMessage");
    msgEl && (msgEl.innerText = "");

    const username = (document.getElementById("reg_username") || {}).value || "";
    const password = (document.getElementById("reg_password") || {}).value || "";
    if (!username || !password) {
      msgEl && (msgEl.innerText = "Username dan password wajib diisi.");
      return;
    }

    try {
      // ✅ pakai /api/auth/register
      const res = await apiPost("/api/auth/register", { username, password });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data.success) {
        const msg = data.msg || data.error || data.message || "Register gagal.";
        msgEl && (msgEl.innerText = msg);
        return;
      }

      msgEl && (msgEl.innerText = "Register berhasil. Silakan login.");
      setTimeout(() => (window.location.href = "login.html"), 1000);
    } catch (err) {
      console.error("Register error:", err);
      msgEl && (msgEl.innerText = "Gagal terhubung ke server.");
    }
  });
}

///// ====== QUIZ (state + UI) ======
let quizState = {
  questions: [],
  quizId: null,
  current: 0,
  answers: {} // keys are index as strings e.g. "0": "Pilihan A"
};

function startQuiz(questions, quizId) {
  // ensure each question has index property (fallback)
  questions = (questions || []).map((q, i) => {
    if (typeof q.index === "undefined") q.index = i;
    return q;
  });

  quizState = { questions, quizId, current: 0, answers: {} };

  // show game UI
  document.getElementById("quizSetup")?.classList.add("hidden");
  document.getElementById("quizResult")?.classList.add("hidden");
  document.getElementById("quizGame")?.classList.remove("hidden");

  showQuestion();
}

function showQuestion() {
  const q = quizState.questions[quizState.current];
  if (!q) return;

  const qEl = document.getElementById("quizQuestion");
  const optEl = document.getElementById("quizOptions");
  const progressEl = document.getElementById("quizProgress");
  const nextBtn = document.getElementById("btnNext");

  qEl.textContent = qText(q) || "(soal tidak tersedia)";
  optEl.innerHTML = "";

  // render options as clickable boxes (grid handled in CSS)
  (q.options || []).forEach((opt) => {
    const box = document.createElement("div");
    box.className = "quiz-option";
    box.tabIndex = 0;
    box.dataset.value = opt;
    box.textContent = opt;

    // mark selected if previously answered
    const prev = quizState.answers[String(q.index)];
    if (prev && norm(prev) === norm(opt)) {
      box.classList.add("selected");
    }

    box.addEventListener("click", () => {
      // clear other selected
      Array.from(optEl.children).forEach((c) => c.classList.remove("selected"));
      box.classList.add("selected");
      quizState.answers[String(q.index)] = opt;
    });

    box.addEventListener("keypress", (ev) => {
      if (ev.key === "Enter" || ev.key === " ") {
        box.click();
        ev.preventDefault();
      }
    });

    optEl.appendChild(box);
  });

  progressEl.textContent = `Soal ${quizState.current + 1} dari ${quizState.questions.length}`;
  nextBtn.classList.remove("hidden");

  nextBtn.onclick = () => {
    const sel = optEl.querySelector(".quiz-option.selected");
    quizState.answers[String(q.index)] = sel ? sel.dataset.value : null;

    quizState.current++;
    if (quizState.current < quizState.questions.length) {
      showQuestion();
    } else {
      finishQuiz();
    }
  };
}

///// finishQuiz
async function finishQuiz() {
  document.getElementById("quizGame")?.classList.add("hidden");
  const resultEl = document.getElementById("quizResult");
  resultEl.classList.remove("hidden");

  const questions = quizState.questions || [];
  const total = questions.length;
  let correct = 0;
  const reviewHtml = [];

  for (const q of questions) {
    const qid = String(q.index);
    const userAns = quizState.answers[qid] || "";
    let correctAnsRaw = q.answer || "";
    let correctAnsToShow = correctAnsRaw;

    let isCorrect = false;
    if (userAns) {
      if (norm(userAns) === norm(correctAnsRaw)) {
        isCorrect = true;
      } else {
        const idx = parseInt(correctAnsRaw, 10);
        if (!isNaN(idx) && q.options && q.options[idx]) {
          correctAnsToShow = q.options[idx];
          if (norm(userAns) === norm(correctAnsToShow)) isCorrect = true;
        } else if (/^[A-Da-d]$/.test(correctAnsRaw) && q.options) {
          const letterIdx = correctAnsRaw.toUpperCase().charCodeAt(0) - 65;
          if (q.options[letterIdx]) {
            correctAnsToShow = q.options[letterIdx];
            if (norm(userAns) === norm(correctAnsToShow)) isCorrect = true;
          }
        } else {
          const foundOpt = (q.options || []).find((opt) => {
            return (
              norm(opt) === norm(correctAnsRaw) ||
              norm(opt).includes(norm(correctAnsRaw)) ||
              norm(correctAnsRaw).includes(norm(opt))
            );
          });
          if (foundOpt) {
            correctAnsToShow = foundOpt;
            if (norm(userAns) === norm(foundOpt)) isCorrect = true;
          }
        }
      }
    }

    if (isCorrect) correct++;

    const optsHtml = (q.options || [])
      .map((o) => {
        const cls =
          norm(o) === norm(correctAnsToShow)
            ? "correct-opt"
            : norm(o) === norm(userAns) && !isCorrect
            ? "wrong-opt"
            : "";
        return `<div class="opt ${cls}">${escapeHtml(o)}</div>`;
      })
      .join("");

    reviewHtml.push(`
      <div class="review-item">
        <div class="r-q"><b>${escapeHtml(qText(q))}</b></div>
        <div class="r-options">${optsHtml}</div>
        <div class="r-ans">
          Jawaban kamu: <strong style="color:${isCorrect ? "#00e676" : "#ff5252"}">${escapeHtml(
      userAns || "(kosong)"
    )}</strong><br>
          Jawaban benar: <strong style="color:#00e676">${escapeHtml(correctAnsToShow)}</strong>
        </div>
      </div>
    `);
  }

  const scorePercent = total > 0 ? Math.round((correct / total) * 100) : 0;
  resultEl.innerHTML = `<h2>Hasil Quiz</h2><p>Skor kamu: ${scorePercent}% (${correct} / ${total})</p><div class="review-list">${reviewHtml.join(
    ""
  )}</div>`;

  try {
    const username = localStorage.getItem("username") || "anonymous";
    const payloadAnswers = {};
    for (const k in quizState.answers) {
      payloadAnswers[String(k)] = quizState.answers[k];
    }

    if (quizState.quizId) {
      const res = await apiPost(`/api/quiz/${quizState.quizId}/submit`, {
        username,
        answers: payloadAnswers,
      });
      const serverData = await res.json().catch(() => ({}));
      if (res.ok && serverData.score_percent !== undefined) {
        const p = resultEl.querySelector("p");
        if (p)
          p.innerText = `Skor kamu: ${serverData.score_percent}% (${serverData.correct} / ${serverData.total})`;
      }
    }
  } catch (err) {
    console.warn("Gagal submit ke server (tidak fatal):", err);
  }
}

///// ====== escapeHtml helper ======
function escapeHtml(str) {
  if (str === null || typeof str === "undefined") return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/>/g, "&gt;")
    .replace(/</g, "&lt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

///// ====== CHAT ======
const chatForm = document.getElementById("chatForm");
if (chatForm) {
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = document.getElementById("chatInput");
    const msg = input.value.trim();
    if (!msg) return;

    const username = localStorage.getItem("username") || "anonymous";
    appendChat("user", msg);

    try {
      const res = await apiPost("/api/chat", { username, message: msg });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) throw new Error(data.error || "Gagal kirim chat");

      appendChat("bot", data.reply);
    } catch (err) {
      console.error("Chat error:", err);
      appendChat("bot", "⚠️ Gagal kirim pesan.");
    }
    input.value = "";
  });
}

function appendChat(role, text) {
  const box = document.getElementById("chatBox");
  if (!box) return;

  const div = document.createElement("div");
  div.className = `chat-message ${role}`;
  div.innerHTML = `
    <div class="chat-bubble">
      <span class="avatar">${role === "user" ? "👤" : "🤖"}</span>
      <span class="msg-text">${escapeHtml(text)}</span>
    </div>
  `;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

///// ====== LOGOUT ======
const btnLogout = document.getElementById("btnLogout");
if (btnLogout) {
  btnLogout.addEventListener("click", (e) => {
    e.preventDefault();
    localStorage.removeItem("username");
    window.location.href = "login.html";
  });
}

