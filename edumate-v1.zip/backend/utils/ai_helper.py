# ai_helper.py - Gemini wrapper + parsing helper
import os
import json
import re
from typing import Optional

try:
    import google.generativeai as genai
except Exception:
    genai = None

# ======================================================
#  🔹 Konfigurasi API
# ======================================================
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# Urutan prioritas model (disesuaikan ke versi baru)
MODEL_PRIORITY = [
    "models/gemini-2.5-flash",
    "models/gemini-flash-latest",
    "models/gemini-2.5-pro",
    "models/gemini-pro-latest",
]

EMBED_MODEL = "models/embedding-gecko-001"

if GEMINI_API_KEY and genai:
    genai.configure(api_key=GEMINI_API_KEY)


# ======================================================
#  🔹 Deteksi model terbaik + tampilkan log model list
# ======================================================
def get_available_model():
    if not GEMINI_API_KEY or not genai:
        print("[AI INIT] ❌ API Key atau SDK belum diatur.")
        return None

    try:
        print("\n[AI INIT] 🔍 Mengecek daftar model yang tersedia dari Google Gemini...\n")
        models = genai.list_models()
        model_names = [m.name for m in models]

        print("──────────────────────────────────────────────")
        for m in model_names:
            print(f" • {m}")
        print("──────────────────────────────────────────────\n")

        # Pilih model terbaik berdasarkan prioritas
        for pref in MODEL_PRIORITY:
            if any(pref in m for m in model_names):
                print(f"[AI INIT] ✅ Menggunakan model: {pref}")
                return pref

        print("[AI INIT] ⚠️ Tidak menemukan model prioritas, fallback ke models/gemini-flash-latest")
        return "models/gemini-flash-latest"

    except Exception as e:
        print(f"[AI INIT] ⚠️ Gagal memeriksa model list: {e}")
        return "models/gemini-flash-latest"


MODEL_NAME = get_available_model()
print(f"[AI READY] 🚀 Model aktif sekarang: {MODEL_NAME}")


# ======================================================
#  🔹 Fungsi generate teks dari Gemini
# ======================================================
def ask_gemini_raw(prompt: str, max_output_tokens: int = 512) -> str:
    if not GEMINI_API_KEY or not genai:
        return "[AI Unavailable] GEMINI_API_KEY not set or sdk missing."

    try:
        model = genai.GenerativeModel(MODEL_NAME)
        response = model.generate_content(
            prompt,
            generation_config={"max_output_tokens": max_output_tokens}
        )
        return getattr(response, "text", str(response))
    except Exception as e:
        return f"[AI Error] {str(e)}"


# ======================================================
#  🔹 Fungsi untuk membuat embedding (semantic search)
# ======================================================
def create_embedding(text: str):
    """
    Membuat representasi vektor dari teks untuk similarity search.
    Cocok buat Kamus Edumate / Edumate Brain.
    """
    if not GEMINI_API_KEY or not genai:
        return None
    try:
        response = genai.embed_content(
            model=EMBED_MODEL,
            content=text
        )
        return response.get("embedding", [])
    except Exception as e:
        print(f"[AI Embed Error] {e}")
        return None


# ======================================================
#  🔹 Helper tambahan (chat & quiz)
# ======================================================
def generate_chat_reply(user_message: str, username: Optional[str] = None) -> str:
    ctx = (
        "Kamu adalah tutor AI yang ramah dan jelas. "
        "Jawab singkat, mudah dimengerti oleh siswa SMA. Berikan contoh jika perlu."
    )
    user_ctx = f"User: {username}" if username else ""
    prompt = f"{ctx}\n{user_ctx}\nPertanyaan: {user_message}\nJawab singkat:"
    return ask_gemini_raw(prompt, max_output_tokens=300)


def generate_quiz_questions(category: str, total: int = 30) -> str:
    prompt = (
        f"Buat {total} soal pilihan ganda tentang topik '{category}'.\n"
        "Untuk setiap soal berikan: soal (text), opsi A/B/C/D, dan jawaban benar.\n"
        "Output harus dalam format JSON array seperti:\n"
        "[{\"q\":\"...\",\"options\":[\"...\",\"...\",\"...\",\"...\"],\"answer\":\"A\"}]\n"
        "Jangan sertakan penjelasan. Hanya output JSON."
    )
    return ask_gemini_raw(prompt, max_output_tokens=2000)


def parse_possible_json(raw: str):
    """
    Coba ekstrak JSON array dari output AI, auto perbaiki format ringan.
    """
    if not raw:
        raise ValueError("Empty AI output")

    start = raw.find("[")
    end = raw.rfind("]")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("No JSON array found in raw output")

    substr = raw[start:end + 1]
    substr = re.sub(r",\s*]", "]", substr)

    try:
        return json.loads(substr)
    except Exception as e:
        raise ValueError(f"JSON parse error: {e}\nRaw snippet: {substr[:200]}")


